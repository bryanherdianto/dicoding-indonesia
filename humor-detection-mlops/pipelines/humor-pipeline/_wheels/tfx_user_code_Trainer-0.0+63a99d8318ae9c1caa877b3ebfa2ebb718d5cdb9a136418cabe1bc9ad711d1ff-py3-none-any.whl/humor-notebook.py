#!/usr/bin/env python
# coding: utf-8

# # Humor Detection

# - Nama: Bryan Herdianto
# - Email: bryan.herdianto17@gmail.com
# - ID Dicoding: bryanherdianto

# ## Import Library

# In[1]:


import tensorflow as tf
import tensorflow_model_analysis as tfma
from tfx.components import CsvExampleGen, StatisticsGen, SchemaGen, ExampleValidator, Transform, Trainer, Tuner, Pusher
from tfx.proto import example_gen_pb2, trainer_pb2, pusher_pb2
from tfx.orchestration.experimental.interactive.interactive_context import InteractiveContext
from tfx.dsl.components.common.resolver import Resolver 
from tfx.dsl.input_resolution.strategies.latest_blessed_model_strategy import LatestBlessedModelStrategy 
from tfx.types import Channel 
from tfx.types.standard_artifacts import Model, ModelBlessing
import os
import requests
from pprint import PrettyPrinter


# ## Set Variable

# In[2]:


PIPELINE_NAME = "humor-pipeline"
SCHEMA_PIPELINE_NAME = "humor-tfdv-schema"

# Directory untuk menyimpan artifact yang akan dihasilkan
PIPELINE_ROOT = os.path.join('pipelines', PIPELINE_NAME)

# Path to a SQLite DB file to use as an MLMD storage.
METADATA_PATH = os.path.join('metadata', PIPELINE_NAME, 'metadata.db')

# Output directory where created models from the pipeline will be exported.
SERVING_MODEL_DIR = os.path.join('serving_model', PIPELINE_NAME)

# from absl import logging
# logging.set_verbosity(logging.INFO)


# In[3]:


DATA_ROOT = "data"


# In[4]:


interactive_context = InteractiveContext(pipeline_root=PIPELINE_ROOT)


# ## Data Ingestion

# In[7]:


output = example_gen_pb2.Output(
    split_config = example_gen_pb2.SplitConfig(splits=[
        example_gen_pb2.SplitConfig.Split(name="train", hash_buckets=8),
        example_gen_pb2.SplitConfig.Split(name="eval", hash_buckets=2)
    ])
)
example_gen = CsvExampleGen(input_base=DATA_ROOT, output_config=output)


# In[8]:


interactive_context.run(example_gen)


# ## Data Validation

# In[9]:


statistics_gen = StatisticsGen(
    examples=example_gen.outputs["examples"]
)
interactive_context.run(statistics_gen)


# In[10]:


interactive_context.show(statistics_gen.outputs["statistics"])


# In[11]:


schema_gen = SchemaGen(
    statistics=statistics_gen.outputs["statistics"]
)
interactive_context.run(schema_gen)


# In[12]:


interactive_context.show(schema_gen.outputs["schema"])


# In[13]:


example_validator = ExampleValidator(
    statistics=statistics_gen.outputs['statistics'],
    schema=schema_gen.outputs['schema']
)
interactive_context.run(example_validator)


# In[14]:


interactive_context.show(example_validator.outputs['anomalies'])


# ## Data Preprocessing

# In[15]:


TRANSFORM_MODULE_FILE = "humor_transform.py"


# In[16]:


get_ipython().run_cell_magic('writefile', '{TRANSFORM_MODULE_FILE}', '\nimport tensorflow as tf\n\nLABEL_KEY = "humor"\nFEATURE_KEY = "text"\n\ndef transformed_name(key):\n    """Renaming transformed features"""\n    return key + "_xf"\n    \ndef preprocessing_fn(inputs):\n    """\n    Preprocess input features into transformed features\n    \n    Args:\n        inputs: map from feature keys to raw features.\n    \n    Return:\n        outputs: map from feature keys to transformed features.    \n    """\n    \n    outputs = {}\n    \n    outputs[transformed_name(FEATURE_KEY)] = tf.strings.lower(inputs[FEATURE_KEY])\n    \n    outputs[transformed_name(LABEL_KEY)] = tf.cast(inputs[LABEL_KEY], tf.int64)\n    \n    return outputs\n')


# In[17]:


transform = Transform(
    examples=example_gen.outputs['examples'],
    schema=schema_gen.outputs['schema'],
    module_file=os.path.abspath(TRANSFORM_MODULE_FILE)
)
interactive_context.run(transform)


# ## Hyperparameter Tuning

# In[18]:


TUNER_MODULE_FILE = "humor_tuner.py"


# In[19]:


get_ipython().run_cell_magic('writefile', '{TUNER_MODULE_FILE}', '\nimport tensorflow as tf\nimport kerastuner as kt\nimport tensorflow_transform as tft\nfrom kerastuner import Hyperband\nfrom tfx.components.tuner.component import TunerFnResult\nfrom tensorflow.keras import layers\n\nLABEL_KEY = "humor"\nFEATURE_KEY = "text"\n\ndef transformed_name(key):\n    """Renaming transformed features"""\n    return key + "_xf"\n\ndef gzip_reader_fn(filenames):\n    """Loads compressed data"""\n    return tf.data.TFRecordDataset(filenames, compression_type=\'GZIP\')\n\ndef input_fn(file_pattern, \n             tf_transform_output,\n             num_epochs,\n             batch_size=64)->tf.data.Dataset:\n    """Get post_tranform feature & create batches of data"""\n    \n    # Get post_transform feature spec\n    transform_feature_spec = (\n        tf_transform_output.transformed_feature_spec().copy())\n    \n    # create batches of data\n    dataset = tf.data.experimental.make_batched_features_dataset(\n        file_pattern=file_pattern,\n        batch_size=batch_size,\n        features=transform_feature_spec,\n        reader=gzip_reader_fn,\n        num_epochs=num_epochs,\n        label_key = transformed_name(LABEL_KEY))\n    return dataset\n\n# Vocabulary size and number of words in a sequence.\nVOCAB_SIZE = 10000\nSEQUENCE_LENGTH = 100\n \nvectorize_layer = layers.TextVectorization(\n    standardize="lower_and_strip_punctuation",\n    max_tokens=VOCAB_SIZE,\n    output_mode=\'int\',\n    output_sequence_length=SEQUENCE_LENGTH)\n \nembedding_dim=16\n\ndef model_builder(hp):\n    """Build machine learning model"""\n\n    # Define the hyperparameters to be tuned\n    hp_embedding_dim = hp.Int(\'embedding_dim\', min_value=32, max_value=128, step=32)\n    hp_dense_1_units = hp.Int(\'dense_1_units\', min_value=32, max_value=128, step=32)\n    hp_dense_2_units = hp.Int(\'dense_2_units\', min_value=16, max_value=64, step=16)\n    hp_learning_rate = hp.Float(\'learning_rate\', min_value=1e-4, max_value=1e-2, sampling=\'LOG\')\n    \n    inputs = tf.keras.Input(shape=(1,), name=transformed_name(FEATURE_KEY), dtype=tf.string)\n    reshaped_narrative = tf.reshape(inputs, [-1])\n    x = vectorize_layer(reshaped_narrative)\n    x = layers.Embedding(VOCAB_SIZE, hp_embedding_dim, name="embedding")(x)\n    x = layers.GlobalAveragePooling1D()(x)\n    x = layers.Dense(hp_dense_1_units, activation=\'relu\')(x)\n    x = layers.Dense(hp_dense_2_units, activation="relu")(x)\n    outputs = layers.Dense(1, activation=\'sigmoid\')(x)\n    \n    model = tf.keras.Model(inputs=inputs, outputs = outputs)\n    \n    model.compile(\n        loss = \'binary_crossentropy\',\n        optimizer=tf.keras.optimizers.Adam(hp_learning_rate),\n        metrics=[tf.keras.metrics.BinaryAccuracy()]\n    )\n    \n    # print(model)\n    model.summary()\n    \n    return model \n\ndef tuner_fn(fn_args):\n    """\n    Build the tuner using the KerasTuner API.\n    Args:\n    fn_args: Holds args used to tune models as name/value pairs.\n    \n    Returns:\n    A namedtuple contains the following:\n    - tuner: A BaseTuner that will be used for tuning.\n    - fit_kwargs: Args to pass to tuner\'s run_trial function for fitting the\n                  model , e.g., the training and validation dataset. Required\n                  args depend on the above tuner\'s implementation.\n    """\n    # Memuat training dan validation dataset yang telah di-preprocessing\n    tf_transform_output = tft.TFTransformOutput(fn_args.transform_graph_path)\n    \n    train_set = input_fn(fn_args.train_files[0], tf_transform_output, 10)\n    val_set = input_fn(fn_args.eval_files[0], tf_transform_output, 10)\n    vectorize_layer.adapt(\n        [j[0].numpy()[0] for j in [\n            i[0][transformed_name(FEATURE_KEY)]\n                for i in list(train_set)]])\n\n    stop_early = tf.keras.callbacks.EarlyStopping(monitor=\'val_loss\', patience=5)\n    \n    # Mendefinisikan strategi hyperparameter tuning\n    tuner = kt.Hyperband(model_builder,\n                         objective=\'val_binary_accuracy\',\n                         max_epochs=5,\n                         factor=3,\n                         directory=fn_args.working_dir,\n                         project_name=\'kt_hyperband\')\n    \n    return TunerFnResult(\n        tuner=tuner,\n        fit_kwargs={ \n            "callbacks":[stop_early],\n            \'x\': train_set,\n            \'validation_data\': val_set,\n            \'steps_per_epoch\': fn_args.train_steps,\n            \'validation_steps\': fn_args.eval_steps\n      }\n  )\n')


# In[20]:


tuner = Tuner(
    module_file=os.path.abspath(TUNER_MODULE_FILE),
    examples=transform.outputs['transformed_examples'],
    transform_graph=transform.outputs['transform_graph'],
    schema=schema_gen.outputs['schema'],
    train_args=trainer_pb2.TrainArgs(splits=['train'], num_steps=500),
    eval_args=trainer_pb2.EvalArgs(splits=['eval'], num_steps=100)
)
 
interactive_context.run(tuner)


# ## Pengembangan Model

# In[21]:


TRAINER_MODULE_FILE = "humor_trainer.py"


# In[22]:


get_ipython().run_cell_magic('writefile', '{TRAINER_MODULE_FILE}', '\nimport tensorflow as tf\nimport tensorflow_transform as tft \nfrom tensorflow.keras import layers\nimport os  \nimport tensorflow_hub as hub\nfrom tfx.components.trainer.fn_args_utils import FnArgs\n \nLABEL_KEY = "humor"\nFEATURE_KEY = "text"\n \ndef transformed_name(key):\n    """Renaming transformed features"""\n    return key + "_xf"\n \ndef gzip_reader_fn(filenames):\n    """Loads compressed data"""\n    return tf.data.TFRecordDataset(filenames, compression_type=\'GZIP\')\n \ndef input_fn(file_pattern, \n             tf_transform_output,\n             num_epochs,\n             batch_size=64)->tf.data.Dataset:\n    """Get post_tranform feature & create batches of data"""\n    \n    # Get post_transform feature spec\n    transform_feature_spec = (\n        tf_transform_output.transformed_feature_spec().copy())\n    \n    # create batches of data\n    dataset = tf.data.experimental.make_batched_features_dataset(\n        file_pattern=file_pattern,\n        batch_size=batch_size,\n        features=transform_feature_spec,\n        reader=gzip_reader_fn,\n        num_epochs=num_epochs,\n        label_key = transformed_name(LABEL_KEY))\n    return dataset\n \n# os.environ[\'TFHUB_CACHE_DIR\'] = \'/hub_chace\'\n# embed = hub.KerasLayer("https://tfhub.dev/google/universal-sentence-encoder/4")\n \n# Vocabulary size and number of words in a sequence.\nVOCAB_SIZE = 10000\nSEQUENCE_LENGTH = 100\n \nvectorize_layer = layers.TextVectorization(\n    standardize="lower_and_strip_punctuation",\n    max_tokens=VOCAB_SIZE,\n    output_mode=\'int\',\n    output_sequence_length=SEQUENCE_LENGTH)\n \nembedding_dim=16\n\ndef model_builder(hp):\n    """Build machine learning model"""\n\n    # Define the hyperparameters to be tuned\n    hp_embedding_dim = hp[\'embedding_dim\']\n    hp_dense_1_units = hp[\'dense_1_units\']\n    hp_dense_2_units = hp[\'dense_2_units\']\n    hp_learning_rate = hp[\'learning_rate\']\n    \n    inputs = tf.keras.Input(shape=(1,), name=transformed_name(FEATURE_KEY), dtype=tf.string)\n    reshaped_narrative = tf.reshape(inputs, [-1])\n    x = vectorize_layer(reshaped_narrative)\n    x = layers.Embedding(VOCAB_SIZE, hp_embedding_dim, name="embedding")(x)\n    x = layers.GlobalAveragePooling1D()(x)\n    x = layers.Dense(hp_dense_1_units, activation=\'relu\')(x)\n    x = layers.Dense(hp_dense_2_units, activation="relu")(x)\n    outputs = layers.Dense(1, activation=\'sigmoid\')(x)\n    \n    model = tf.keras.Model(inputs=inputs, outputs = outputs)\n    \n    model.compile(\n        loss = \'binary_crossentropy\',\n        optimizer=tf.keras.optimizers.Adam(hp_learning_rate),\n        metrics=[tf.keras.metrics.BinaryAccuracy()]\n    )\n    \n    # print(model)\n    model.summary()\n    \n    return model \n \ndef _get_serve_tf_examples_fn(model, tf_transform_output):\n    \n    model.tft_layer = tf_transform_output.transform_features_layer()\n    \n    @tf.function\n    def serve_tf_examples_fn(serialized_tf_examples):\n        \n        feature_spec = tf_transform_output.raw_feature_spec()\n        \n        feature_spec.pop(LABEL_KEY)\n        \n        parsed_features = tf.io.parse_example(serialized_tf_examples, feature_spec)\n        \n        transformed_features = model.tft_layer(parsed_features)\n        \n        # get predictions using the transformed features\n        return model(transformed_features)\n        \n    return serve_tf_examples_fn\n    \ndef run_fn(fn_args: FnArgs) -> None:\n    log_dir = os.path.join(os.path.dirname(fn_args.serving_model_dir), \'logs\')\n    \n    tensorboard_callback = tf.keras.callbacks.TensorBoard(\n        log_dir = log_dir, update_freq=\'batch\'\n    )\n    \n    es = tf.keras.callbacks.EarlyStopping(monitor=\'loss\', mode=\'max\', verbose=1, patience=10)\n    mc = tf.keras.callbacks.ModelCheckpoint(fn_args.serving_model_dir, monitor=\'loss\', mode=\'max\', verbose=1, save_best_only=True)\n    \n    # Load the transform output\n    tf_transform_output = tft.TFTransformOutput(fn_args.transform_graph_path)\n    \n    # Create batches of data\n    train_set = input_fn(fn_args.train_files, tf_transform_output, 10)\n    val_set = input_fn(fn_args.eval_files, tf_transform_output, 10)\n    vectorize_layer.adapt(\n        [j[0].numpy()[0] for j in [\n            i[0][transformed_name(FEATURE_KEY)]\n                for i in list(train_set)]])\n\n    # Load the best hyperparameters from tuner\n    best_hyperparameters = fn_args.hyperparameters.get(\'values\')\n    \n    # Build the model\n    model = model_builder(best_hyperparameters)\n    \n    # Train the model\n    model.fit(\n        x=train_set,\n        validation_data=val_set,\n        callbacks=[tensorboard_callback, es, mc],\n        steps_per_epoch=1000, \n        validation_steps=1000,\n        epochs=10\n    )\n    \n    signatures = {\n        \'serving_default\': _get_serve_tf_examples_fn(model, tf_transform_output).get_concrete_function(\n            tf.TensorSpec(\n                shape=[None],\n                dtype=tf.string,\n                name=\'examples\'\n            )\n        )\n    }\n\n    # Save the model\n    model.save(fn_args.serving_model_dir, save_format=\'tf\', signatures=signatures)\n')


# In[23]:


trainer = Trainer(
    module_file=os.path.abspath(TRAINER_MODULE_FILE),
    examples=transform.outputs['transformed_examples'],
    transform_graph=transform.outputs['transform_graph'],
    schema=schema_gen.outputs['schema'],
    train_args=trainer_pb2.TrainArgs(splits=['train']),
    eval_args=trainer_pb2.EvalArgs(splits=['eval']),
    hyperparameters=tuner.outputs['best_hyperparameters']
)
interactive_context.run(trainer)


# In[24]:


model_resolver = Resolver(
    strategy_class=LatestBlessedModelStrategy,
    model=Channel(type=Model),
    model_blessing = Channel(type=ModelBlessing)
).with_id('Latest_blessed_model_resolver')
 
interactive_context.run(model_resolver)


# In[27]:


eval_config = tfma.EvalConfig(
    model_specs=[tfma.ModelSpec(label_key='humor')],
    slicing_specs=[tfma.SlicingSpec()],
    metrics_specs=[
        tfma.MetricsSpec(metrics=[
            tfma.MetricConfig(class_name='ExampleCount'),
            tfma.MetricConfig(class_name='AUC'),
            tfma.MetricConfig(class_name='FalsePositives'),
            tfma.MetricConfig(class_name='TruePositives'),
            tfma.MetricConfig(class_name='FalseNegatives'),
            tfma.MetricConfig(class_name='TrueNegatives'),
            tfma.MetricConfig(class_name='BinaryAccuracy',
                              threshold=tfma.MetricThreshold(
                                  value_threshold=tfma.GenericValueThreshold(lower_bound={'value':0.5}),
                                  change_threshold=tfma.GenericChangeThreshold(
                                      direction=tfma.MetricDirection.HIGHER_IS_BETTER,
                                      absolute={'value':0.0001})))
        ])
    ]
)


# In[28]:


from tfx.components import Evaluator
evaluator = Evaluator(
    examples=example_gen.outputs['examples'],
    model=trainer.outputs['model'],
    baseline_model=model_resolver.outputs['model'],
    eval_config=eval_config
)
 
interactive_context.run(evaluator)


# In[29]:


# Visualize the evaluation results
eval_result = evaluator.outputs['evaluation'].get()[0].uri
tfma_result = tfma.load_eval_result(eval_result)
tfma.view.render_slicing_metrics(tfma_result)
tfma.addons.fairness.view.widget_view.render_fairness_indicator(
    tfma_result
)


# ## Deployment

# In[30]:


pusher = Pusher(
    model=trainer.outputs['model'],
    model_blessing=evaluator.outputs['blessing'],
    push_destination=pusher_pb2.PushDestination(
        filesystem=pusher_pb2.PushDestination.Filesystem(
            base_directory='serving_model_dir/humor-detection-model'
        )
    )
)
 
interactive_context.run(pusher)


# In[31]:


pp = PrettyPrinter()
pp.pprint(requests.get("http://localhost:8080/v1/models/humor-detection-model").json())

